# FaceReconX

**FaceReconX** is a Python-based cross-platform face recognition web application that:
- Detects faces from uploaded images.
- Matches faces against known public datasets or social media OSINT images.
- Generates a PDF report of matched faces.
- Runs on localhost and works in any browser.

## Features
- Flask web app.
- Face recognition using `face_recognition` and OpenCV.
- Save reports as downloadable PDFs.
- Ethical OSINT support.

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Open [http://localhost:5000](http://localhost:5000) in your browser.

## Folder Structure

- `dataset/known_faces/` - Place public or known dataset images here.
- `static/uploads/` - Temporary uploaded images.
- `output/reports/` - Auto-generated PDF reports.

## License
MIT License
