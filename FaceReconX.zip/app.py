from flask import Flask, render_template, request, send_file
import face_recognition
import os
import cv2
import numpy as np
from werkzeug.utils import secure_filename
from reportlab.pdfgen import canvas
from datetime import datetime

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads/"
KNOWN_FOLDER = "dataset/known_faces/"
REPORT_FOLDER = "output/reports/"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load known faces
known_encodings = []
known_names = []

for file in os.listdir(KNOWN_FOLDER):
    image = face_recognition.load_image_file(KNOWN_FOLDER + file)
    encoding = face_recognition.face_encodings(image)[0]
    known_encodings.append(encoding)
    known_names.append(file.split(".")[0])

def save_report(name, matches):
    filename = os.path.join(REPORT_FOLDER, f"{name}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf")
    c = canvas.Canvas(filename)
    c.drawString(100, 800, f"Face Recognition Report for: {name}")
    c.drawString(100, 780, "Matched Faces:")
    y = 760
    for match in matches:
        c.drawString(120, y, f"- {match}")
        y -= 20
    c.save()
    return filename

@app.route('/', methods=['GET', 'POST'])
def index():
    result_path = None
    report = None
    matches = []

    if request.method == 'POST':
        file = request.files['image']
        filename = secure_filename(file.filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)

        # Detect faces in uploaded image
        uploaded_image = face_recognition.load_image_file(file_path)
        uploaded_encoding = face_recognition.face_encodings(uploaded_image)

        if uploaded_encoding:
            for face in uploaded_encoding:
                results = face_recognition.compare_faces(known_encodings, face)
                for i, match in enumerate(results):
                    if match:
                        matches.append(known_names[i])

            report = save_report(filename, matches)
        else:
            matches = ["No face detected."]

        result_path = file_path

    return render_template("index.html", image=result_path, matches=matches, report=report)

@app.route('/download/<path:filename>')
def download(filename):
    return send_file(filename, as_attachment=True)

if __name__ == '__main__':
    os.makedirs(REPORT_FOLDER, exist_ok=True)
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(debug=True)
